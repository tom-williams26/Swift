//
//  FilmEntry.swift
//  MyFilms
//
//  Created by user914215 on 2/15/19.
//  Copyright © 2019 Thomas Williams. All rights reserved.
//
// Data Structure for storing the description, photo and comments of a film.

// When using the Foundation framework it allows you to work with Foundation data structures within the code. However, UIKit also gives access to the Foundation framework making the Foundation framework redundant.
import UIKit
import os.log
class FilmEntry:NSObject, NSCoding {
    
    /* Guard statements - A "guard" statement declares a condition that must be true in order for the code after the
     "guard" statement to be executed. If the condition is false, the "guard" statment's else branch must exit the current code block.
    */
    
    // The encode(with:) method prepares the class's information to be archived, and the initalizer unarchives the data when the class is created. Both the encoder and the initializer must be implemented for the data to save and load properly.
    // MARK: NSCoding
    func encode(with aCoder: NSCoder) {
        aCoder.encode(title, forKey:PropertyKey.title);
        aCoder.encode(year, forKey:PropertyKey.year);
        aCoder.encode(genre, forKey:PropertyKey.genre);
        aCoder.encode(ageRating, forKey:PropertyKey.ageRating);
        aCoder.encode(review, forKey:PropertyKey.review);
        aCoder.encode(photo, forKey:PropertyKey.photo)
        aCoder.encode(rating, forKey:PropertyKey.rating);
    }
    
    /*  - The required modifier meant the initializer must be implemented on each subclass, if the subclass defines its own initializers.
        - The convenience modifier means that this is a secondary initializer, and that it must call a designated initializer from the same class.
        - The question mark (?) means that this is a failable initializer that might return nil.
     */
    required convenience init?(coder aDecoder: NSCoder) {
        // Make sure we can decode the title, year, genre, ageRating, reviews, photo.
        // A convenience initializer is required to call one of its class's designated initializers before completing. As the initializer's arguments, it passes values of the constants created while archiving the saved data.
        guard let title = aDecoder.decodeObject(forKey:PropertyKey.title) as? String else{
            os_log("Unable to decode the title for a FilmEntry object", log:OSLog.default, type:
                .debug)
            return nil;
        }
        guard let year = aDecoder.decodeObject(forKey:PropertyKey.year) as? String else{
            os_log("Unable to decode the year for a FilmEntry object", log:OSLog.default, type:
                .debug)
            return nil;
        }
        guard let genre = aDecoder.decodeObject(forKey:PropertyKey.genre) as? String else{
            os_log("Unable to decode the genre for a FilmEntry object", log:OSLog.default, type:
                .debug)
            return nil;
        }
        guard let ageRating = aDecoder.decodeObject(forKey:PropertyKey.ageRating) as? String else{
            os_log("Unable to decode the age rating for a FilmEntry object", log:OSLog.default, type:
                .debug)
            return nil;
        }
        guard let review = aDecoder.decodeObject(forKey:PropertyKey.review) as? String else{
            os_log("Unable to decode the review for a FilmEntry object", log:OSLog.default, type:
                .debug)
            return nil;
        }
        let rating = aDecoder.decodeInteger(forKey: PropertyKey.rating)
        
        let photo = aDecoder.decodeObject(forKey:PropertyKey.photo) as? UIImage;
        
        self.init(title:title, year:year, genre:genre, ageRating:ageRating, review:review, photo:photo, rating:rating);
        
    }
    // MARK: Properties
    // Defines the basic properties for the data needed to be stored. These are set to variables (var) instead of constants (let) because they will change during runtime and the Film object's lifetime.
    var title: String
    var year: String
    var genre: String
    var ageRating: String
    var review: String
    var photo:UIImage?
    var rating: Int
    
    // MARK: Initialization
    // an Initializer is a method that prepares an instance of a class for use, which involves setting an inital value for each property and performing any other setup or initialization ( the initializer returns an optional Film? object ).
    init?(title:String, year:String, genre:String, ageRating:String, review:String, photo:UIImage?, rating:Int){
        // Initialization should fail if there is no input.
        guard ( !title.isEmpty || !year.isEmpty || !genre.isEmpty || !ageRating.isEmpty || !review.isEmpty ) else{
            // nil - to indicate that the item couldn't be created, and has set to the default values.
            return nil;
        }
        // The rating must be between 0 and 5 inclusively.
        guard (rating >= 0) && (rating <= 5) else {
            return nil;
        }
        // Initialize stored properties - setting properties equal to the parameter values.
        self.title = title;
        self.year = year;
        self.genre = genre;
        self.ageRating = ageRating;
        self.review = review;
        self.photo = photo;
        self.rating = rating;
        
    }
    // MARK: Types
    // make data saveable
    struct PropertyKey{
        // static - the keyword indicates that these constants belong to the structure itself, not to instance of the structure. These are accessed by using the structure's name (i.e, PropertyKey.title).
        static let title = "title";
        static let year = "year";
        static let genre = "genre";
        static let ageRating = "ageRating";
        static let review = "review";
        static let photo = "photo";
        static let rating = "rating"
    }
    
    // The DocumentsDirecotry constant uses the file manager's urls(for:in:) method to look up the URL for the app's documents directory. This directory is where the app saves the data for the user.
    static let DocumentsDirectory = FileManager().urls(for:.documentDirectory, in:.userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("FilmEntries");
    // After determining theURL for the documents directory, the URL is used to create the URL for the app's data, the URL is created by appending FilmEntries to the end of the documents URL.
    
    
    
}
