//
//  RatingControl.swift
//  MyFilms
//
//  Created by user914215 on 2/20/19.
//  Copyright © 2019 Thomas Williams. All rights reserved.
//
//      *CUSTOM CONTROL*
/*
 To be able to rate a film, users need a control that lets them select the number of stars they want to assign a film. We do this by building a custom control by combining existing views and controls. A stack view subclass is created which manages the row of buttons representing the stars. This is all implemented within this control and can only be viewable within the storyboard after a successful build.
 */
import UIKit

/*
    Once a user selects a star, that star and the stars preceding it are filled in. If the user taps the rightmost filled in star (the star associated with the current rating), the rating is cleared and all stars are displayed as empty.
 */
/* @IBDesignable lets the interface builder instantiate and draw a copy of the control directly in the canvas. Additionally, now that the interface builder has a live copy of the control, its layout engine can properly position and size the control.
 
 */
@IBDesignable class RatingControl: UIStackView {
    
    // Private methods can only be called by code within the declaring class.
    // This lets you encapsulate and protect methods, ensuring that they are not
    // unexpectedly or accidently called from the outside.
    
    // MARK: Properties
    /* ratingButtons - This property contains the list of buttons for the rating and nothing else outside the RatingControl class can access these
    buttons. Therefore they are declared as private.
     */
    private var ratingButtons = [UIButton]()
    /* rating - This property contains the control's rating. The value must be able to both read and write from outisde the class. By leaving it as internal access (by default), and can be accessed from any other class inside the app.
     */
    var rating = 0 {
        didSet {
            updateButtonSelectionStates()
        }
    }
    // starSize and starCount defines the size of the buttons and the number of buttons in the control.
    @IBInspectable var starSize: CGSize = CGSize(width: 44.0, height: 44.0) {
        didSet {
            setupButtons()
        }
    }
    @IBInspectable var starCount: Int = 5 {
        didSet {
            setupButtons()
        }
    }
    
    //MARK: Initialization
    // These initializers are placeholders that simply call the superclass's implementation.
    override init(frame: CGRect) {
        super.init(frame:frame)
        
        setupButtons()
    }
    
    required init(coder: NSCoder) {
        super.init(coder:coder)
        
        setupButtons()
    }
    
    //MARK: Button Action
    @objc func ratingButtonTapped(button: UIButton) {
        guard let index = ratingButtons.index(of: button) else {
            fatalError("The button, \(button), is not in the ratingButtons array: \(ratingButtons)" )
        }
        
        
        // Calculate the rating of the selected button
        
        let selectedRating = index + 1
        if(selectedRating == rating) {
            // if the selected star represents the current rating, reset the rating to 0.
            rating = 0
        }else{
            // otherwise set the rating to the selected star
            rating = selectedRating
        }
    }
    
    //MARK: Private Methods
    private func setupButtons() {
        
        // clear any existing buttons
        /* Below the code interates over all of the rating control's buttons. Firstly, by removing the button from the list of views managed by the stack view. This tells the stack view that is should no longer calculate the button's size and position - but the button is still a subview of stack view. Next, the buttons are removed from the stack view entirely. Finally, once all the buttons are removed, it clears the "ratingButtons" array.
         */
        for button in ratingButtons {
            removeArrangedSubview(button)
            button.removeFromSuperview()
        }
        
        ratingButtons.removeAll()
        
        // Load Images
        
        let bundle = Bundle(for:type(of:self))
        // Images are loaded from the assets catalog.
        // The images must be loaded properly in the interface builder, as the catalog's bundle must be specified explicitly. Ensuring the system can find and load the image.
        let filledStar = UIImage(named:"filledStar", in: bundle, compatibleWith: self.traitCollection)
        let emptyStar = UIImage(named:"emptyStar", in: bundle, compatibleWith: self.traitCollection)
        let hightlightedStar = UIImage(named:"highlightedStar", in: bundle, compatibleWith: self.traitCollection)
        for index in 0..<starCount {
            
            
            // Create the button
            /*
             UIButton class's convenience initializers. This initializer calls init(frame:) and passes in a zero-sized rectangle.
             Starting with a zero-sized rectangle is fine, because auto layout is being used. The stack view will automatically define the
             button's position, and add constraints to define the button size.
             */
            let button = UIButton()
            
            // Set button images
            // normal - The normal, or default state of a control—that is, enabled but neither selected nor highlighted.
            button.setImage(emptyStar, for: .normal)
            // Selected state of a control.
            button.setImage(filledStar, for: .selected)
            button.setImage(hightlightedStar, for: .highlighted)
            button.setImage(hightlightedStar, for: [.highlighted, .selected])
            
            // Add constraints.
            /* Disables the button's automatically generated constraints. When the view is instaniate, its "translatesAutoresizingMaskIntoConstraints"
             defaults to true. Telling the layout engine to create constraints that define the view's size and position based on the view's
             frame and autoresizingmask properties.
             */
            button.translatesAutoresizingMaskIntoConstraints = false
            /* The button's "heightAnchor" and "widthAnchor" properties give access to layout anchors which are used to create constraints - in this case, constraints that define the view's height and width, respectively.
             
             The anchor's "constraint(equalToConstant:)" method returns a constraint that defines a constant height or width for the view.
             
             The constraint's "isActive property activates or deactivates the constraint. When set to "true", the system adds the constraint to the correct view, and activates it.
            */
            button.heightAnchor.constraint(equalToConstant: starSize.height).isActive = true
            button.widthAnchor.constraint(equalToConstant: starSize.width).isActive = true
            // Together these line define the button as a fixed-size object in the layout (44 point x 44 point).
            // Set the accessibility label
            button.accessibilityLabel = "Set \(index + 1) star rating"
            // Setup the button action.
            /*
             - The target is self, which refers to the current instance of the enclosing class - in this case, it refers to the
             RatingControl object that is seeting up the buttons.
             - The #selector expression returns the Selector value for the provided method. A selector is an opaque value that identifies the method - in this case, #selector(RatingControl.ratingButtonTapped(_:)) expression returns the selector for the "ratingButtonTapped(_:)" action method. this lets the system call the action method when the button is selected.
             - .touchUpInside event - This is used when the user touches the button, and then lifts their finger while their finger is still within the button's bounds. This event has an advantage over ".touchdown", becuase the user can cancel the event by dragging their finger outside the button before lifting it.
             - Becuase the interface builder is not being used, the action method does not need to be defined with the IBAction attribute, the action is define like any other method.
             */
            button.addTarget(self, action: #selector(RatingControl.ratingButtonTapped(button:)), for: .touchUpInside)
            
            // Add the button to the stack.
            
            addArrangedSubview(button)
            
            // Add the new button to the rating button array.
            
            ratingButtons.append(button)
        }
    }
    
    private func updateButtonSelectionStates() {
        for (index, button) in ratingButtons.enumerated() {
            // If the index of a button is less than the rating, that button should be selected.
            button.isSelected = index < rating
            
            // Set the hint string for the currently selected star
            let hintString: String?
            if rating == index + 1 {
                hintString = "Tap to reset the rating to zero."
            }else {
                hintString = nil
            }
            
            // Calculate the value string
            let valueString: String
            switch (rating){
            case 0:
                valueString = "No rating set."
            case 1:
                valueString = "1 star set."
            default:
                // If the rating is greater than 1, the hint is calculated using string interpolation.
                valueString = "\(rating) stars set."
            }
            
            // Assign the hint string and value string
            button.accessibilityHint = hintString
            button.accessibilityValue = valueString
        }
    }
}
