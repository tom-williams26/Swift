//
//  FilmViewController.swift
//  MyFilms
//
//  Created by user914215 on 2/14/19.
//  Copyright © 2019 Thomas Williams. All rights reserved.
//

import UIKit
import QuartzCore
import os.log

class FilmViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextViewDelegate {
    
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var filmRating: RatingControl!
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var yearTextField: UITextField!
    @IBOutlet weak var genreTextField: UITextField!
    @IBOutlet weak var ageRatingTextField: UITextField!
    @IBOutlet weak var reviewsTextField: UITextField!
    @IBOutlet weak var saveFilmButton: UIBarButtonItem!
    
    var film:FilmEntry?;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
      
        self.hideKeyBoardWhenTappedAround()
        titleTextField.delegate = self as? UITextFieldDelegate
        
        if let film = film{
            titleTextField.text = film.title;
            yearTextField.text = film.year;
            genreTextField.text = film.genre;
            ageRatingTextField.text = film.ageRating;
            reviewsTextField.text = film.review;
            photoImageView.image = film.photo;
            self.title = "Edit Film";
            
        }
    }
    
    @IBAction func selectImageFromPhotoLibrary(_ sender: UITapGestureRecognizer) {
        // Notifies the following objects that it has been asked to relinquish its status as first responder in its window.
        
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = .photoLibrary
        
        present(imagePickerController, animated: true, completion: nil)
    }
    
    //imagePickerDelegate methods
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        //dismiss photo picker if the user cancels
        dismiss(animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        //get the original image
        guard let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else{
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)");
        }
        //set photo to display
        photoImageView.image = selectedImage;
        //dismiss picker
        dismiss(animated: true, completion: nil)
    
    }
    // Dismissed the Add Film scene.
    @IBAction func cancelButton(_ sender: Any) {
        // Creates a boolean value that indicates whether the vie controller that presented this scene of type UINavigation Controller.
        // As the constant name isPresentingInAddFilmMode indicates that the film detail scene is presented by the user tapping the add button. This is because the film scene is embedded in its own navigation controller when it's presented in this manner, which means that the navigation controller is what presents it.
            let isPresentingInAddFilmMode = presentingViewController is UINavigationController;
        // Check if the user was adding a film before calling.
            if isPresentingInAddFilmMode{
                // Dismissing the FilmViewController when adding.
                dismiss(animated: true, completion: nil)
            }else{
                // Dimiss the edit film details.
                if let owningNavigationController = navigationController{
                    owningNavigationController.popViewController(animated: true)
                }
        }
    }
    // Lets the user tap anywhere else on the screen to dismiss the keyboard and perhaps do something else.
    @objc func dismissKeyboard(){
     
        view.endEditing(true)
    }
    func hideKeyBoardWhenTappedAround() {
        let tap:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
        
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        titleTextField.resignFirstResponder()
        return true
    }
    //MARK: Navigation
    // Prepare for the film to be saved.
    override func prepare(for segue:UIStoryboardSegue, sender:Any?){
        super.prepare(for: segue, sender: sender)
        // Check for the save button was clicked.
        guard let button = sender as? UIBarButtonItem, button===saveFilmButton else{
            os_log("The save button was not pressed, cancelling", log:OSLog.default, type:.debug)
            // It must have been the cancel button.
            
            return;
        }
        
        let title = titleTextField.text ?? "";
        let year = yearTextField.text ?? "";
        let genre = genreTextField.text ?? "";
        let ageRating = ageRatingTextField.text ?? "";
        let review = reviewsTextField.text ?? "";
        let photo = photoImageView.image;
        let rating = filmRating.rating
        
        // Set the film to be passed to FilmTableViewController after the unwind segue.
        film = FilmEntry(title:title, year:year, genre:genre, ageRating:ageRating, review:review, photo:photo, rating:rating);
    }
    
 
   
}
