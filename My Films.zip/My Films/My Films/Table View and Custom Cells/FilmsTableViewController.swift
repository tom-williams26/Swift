//
//  FilmsTableViewController.swift
//  MyFilms
//
//  Created by user914215 on 2/13/19.
//  Copyright © 2019 Thomas Williams. All rights reserved.
//
// TableView for viewing, adding, editing and deleting films.
import UIKit
import os.log
class FilmsTableViewController: UITableViewController, UISearchBarDelegate {
    
    // Table view cells are reused and should be dequeued using a cell identifier.
    let cellIdentifier = "FilmCell"
   // Mutable arrarys, which means items can be added after they are initialized.
    var filmsArray: [FilmEntry] = []
    var filteredFilms:[FilmEntry] = []
    

    @IBOutlet weak var searchBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyBoardWhenTappedAround()
        
        searchBar.placeholder = "Search film by title..."
        // Do any additional setup after loading the view, typically from a nib.
        self.clearsSelectionOnViewWillAppear = false
        // Use the edit button provided by the table view controller.
        self.navigationItem.leftBarButtonItem = self.editButtonItem
        
        /* If loadFilms() successfully returns an array of Film objects, this condition is true and the if statment is executed. if loadFilms() return nil, there were no films to load and the if statment does not get executed.
            - Loads successful films to the films array.
         */
        if let savedFilms = loadFilms() {
            filmsArray += savedFilms
            // Films are sorted upon start-up of the app.
            filmsArray.sort(by:{$0.title < $1.title})
          
            filteredFilms = filmsArray
        }
        else{
            // Loads a default film.
        }
     
    }
    
    //search bar action - Searches for a film within the list of films.
    func searchBar(_ searchBar:UISearchBar, textDidChange searchText: String){
        
        if searchText.isEmpty {
            filteredFilms = filmsArray
        }else {
            filteredFilms = filmsArray.filter({film-> Bool in
                guard let text = searchBar.text else{return false}
                return film.title.contains(text)
                
                
            });
        }
        tableView.reloadData()
    }
   
    // Lets the user tap anywhere else on the screen to dismiss the keyboard and perhaps do something else.
    // When the user has finished searching closes the keyboard upon tapping outside the keyboard.
    @objc func dismissKeyboard(){
        
        view.endEditing(true)
    }
    func hideKeyBoardWhenTappedAround() {
        let tap:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
        
    }
    
    //MARK: - UITableViewDataSource
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    // Tells the table view how many rows to display in a given section.
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Displays the stored films on the table view.
        return filteredFilms.count
    }
    // Configures and provides a cell to display for a given row. Each row in a table view has one cell, and that cell detemines the content that appears in that row and how that content is laid out.
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "FilmCell", for: indexPath) as? FilmTableViewCell else {
            fatalError("The dequeued cell is not an instance of FilmTableViewCell.")
        }
   
        // Fetches the appropriate film for the data source layout.
        // Sets each of the views in the table view cell to display the corresponding data from film object.
        
        cell.titleLabel?.text = filteredFilms[indexPath.row].title
        cell.yearLabel?.text = filteredFilms[indexPath.row].year
        cell.photoImageView?.image = filteredFilms[indexPath.row].photo
        cell.ratingControl?.rating = filteredFilms[indexPath.row].rating
        
        return cell
    }
    
    //MARK: - UITableViewDelegate
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // return false if you do not want the specified item to be editable.
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
          
            // Get hold of the record to be deleted
            let deletedRecord = filteredFilms[indexPath.row]
            //tableView.deleteRows(at: [indexPath], with: .fade)
            // Delete from the filteredfilms collection/ data source
            filteredFilms.remove(at:indexPath.row)
            
            for i in indexPath.row ..< filmsArray.count{
                if(filmsArray[i].title == deletedRecord.title && filmsArray[i].year == deletedRecord.year){
                    // Update the contact in the original array.
                    filmsArray.remove(at: i)
                    break
                }
            }
            tableView.deleteRows(at: [indexPath], with: .fade)
            saveFilms()
            
        }
    }
    
    // unwindToFilms - This method saves the films array whenever a new one is added or an existing one is updated.
    @IBAction func unwindToFilms(sender:UIStoryboardSegue){
        // Downcast to addFilmViewController.
        if let sourceViewController = sender.source as? FilmViewController, let film = sourceViewController.film{
            
            // Check if this is an edit.
            if let selectedIndexPath = tableView.indexPathForSelectedRow{
                let selectedRecord = filteredFilms[selectedIndexPath.row]
                
                // Update the film.
                filteredFilms[selectedIndexPath.row] = film
                
                for i in selectedIndexPath.row ..< filmsArray.count{
                    if(filmsArray[i].title == selectedRecord.title && filmsArray[i].year == selectedRecord.year){
                        // Update the film in the original array
                        filmsArray[i] = film
                        break
                    }
                }
                // This reloads from the filtered array.
                tableView.reloadRows(at:[selectedIndexPath], with:.none)
            }else{
                
                // Add to list of films.
                let newIndexPath = IndexPath(row:filmsArray.count, section:0)
                
                filmsArray.append(film);
                filteredFilms.append(film)
                // Inserts a new row.
                
                tableView.insertRows(at:[newIndexPath], with:.automatic)
            }
            // Save the films
            saveFilms()
        }
    }
    // MARK: - Navigation
    // Retrieves the destination view controller, the selected film cell and the index path of the selected cell.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        
        super.prepare(for:segue, sender:sender)
        // Guard statments check that all the downcasts work as expected and all optionals contain non-nil values.
        // If the story board is set up correctly, none of the guard statments will fail.
        switch(segue.identifier ?? ""){
        case "AddFilm":
            // Fine
            break;
        case "ViewFilm":
            // Load the details of the film selected and pass it to the new view.
            guard let filmViewController = segue.destination as? FilmViewController else{
                fatalError("Unexpected destination")
            }
            guard let indexPath = tableView.indexPathForSelectedRow else{
                fatalError("The selected cell is not being displayed by the table")
            }
     
            
            let selectedFilm = filteredFilms[indexPath.row]
            filmViewController.film = selectedFilm
            break
        default:
            // Default case will never execute as long as the story board is sent up correctly.
            // If the prepare(for:sender:) is not updated after adding another segue, the new segue identifier wont match either the AddFilm or ViewFilm and prints a error message to the console and terminates the app!
            fatalError("Unexpected segue")
        }
    }
    
    //MARK: Private methods
    
    private func saveFilms() {
        // This method attempts to archive the films array to a specific location, and returns true if it's succesful. It uses the constant FilmEntry.ArchiveURL to identify where to save information.
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(filmsArray, toFile: FilmEntry.ArchiveURL.path)
        // This logs a debug message to the console if the save succeeds, and an error message to the console if the save fails.
        if(isSuccessfulSave){
            os_log("Films successfully saved.", log:OSLog.default, type: .debug)
        }else{
            os_log("Failed to save films...", log:OSLog.default, type: .error)
        }
    }
    
    private func loadFilms() -> [FilmEntry]? {
        // This method attempts to unarchive the object stored at the path FilmEntry.ArchiveURL.path and downcast that object to an array of FilmEntry object.
        return NSKeyedUnarchiver.unarchiveObject(withFile: FilmEntry.ArchiveURL.path) as? [FilmEntry]
    }
    
    
    
}
