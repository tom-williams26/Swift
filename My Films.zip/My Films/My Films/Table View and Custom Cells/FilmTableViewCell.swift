//
//  FilmTableViewCell.swift
//  My Films
//
//  Created by user914215 on 3/4/19.
//  Copyright © 2019 Thomas Williams. All rights reserved.
//
// Custom table view cell.
import UIKit

class FilmTableViewCell: UITableViewCell {

    
    //MARK: Properties
    
    // Displays the title, image, year of film and rating out of five stars on the table view.
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var ratingControl: RatingControl!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
